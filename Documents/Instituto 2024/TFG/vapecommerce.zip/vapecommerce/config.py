# config.py
class Config:
    SQLALCHEMY_DATABASE_URI = "sqlite:///main_placeholder.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
