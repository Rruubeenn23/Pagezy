import { initCarrusel } from "./componentes/carrusel.js";

document.addEventListener("DOMContentLoaded", () => {
  initCarrusel();
});
